### Application Code

<img width="1280" height="720" alt="GCP-Project" src="https://github.com/user-attachments/assets/38fe01de-c6cc-4451-b068-c3d0c8d996a7" />

### Helm Chart Repo url:

```
https://github.com/vijaygiduthuri/test-k8s.git
```

### Medium Blog Link:  

```
https://medium.com/@vijaygiduthuri67/google-cloud-project-c44cee552094
```

### Youtube Video Link:

```
https://youtu.be/XBRkFyK6D0k?si=fTiMznG-V1krMlhF
```


